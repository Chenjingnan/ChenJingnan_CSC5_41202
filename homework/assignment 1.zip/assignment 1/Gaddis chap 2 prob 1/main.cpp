/* 
 * File:   main.cpp
 * Author: Jingnan Chen
 * Created on January 10, 2016, 3:42 PM
 * Purpose:Sum of two numbers
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constant
int main()
{
    int a;
    int b;
    int Sum;
    
    a=50;
    b=100;
    Sum=a+b;
    
    cout<<"Sum of "<< a<<" and "<< b<<" is "<< Sum<<endl;

    return 0;
}

