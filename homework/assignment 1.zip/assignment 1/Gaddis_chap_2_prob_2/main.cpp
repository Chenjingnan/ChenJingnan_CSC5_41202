/* 
 * File:   main.cpp
 * Author: Jingnan Chen
 * Created on January 10, 2016, 4:00 PM
 * Purpose:Sales Prediction
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constant
int main()
{
    float a=8.6e6;
    
    double b=a*0.58;
    
    cout<<"How much the company will generate is $ "<<b<<endl;

    return 0;
}

